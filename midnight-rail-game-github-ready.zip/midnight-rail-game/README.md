# Midnight Rail: The Lost Stop

This is the full GitHub-ready React/Vite project.

## Folder structure

```txt
midnight-rail-game/
  index.html
  package.json
  vite.config.ts
  tsconfig.json
  src/
    main.tsx
    App.tsx
    App.css
  public/
    assets/
      old-north-station.png
      midnight-carriage.png
      black-hollow-square.png
      station-records-room.png
      mr-gray.png
      luna-bell.png
      detective-stone.png
      finn-fox.png
```

## Important

Upload your 8 images into `public/assets/` using the exact names above.

## Deploy

Upload this folder to GitHub, then import the repository into Vercel.
